//
//  FUFonts.h
//  ficUtilities
//
//  Created by Csengeri Máté on 11/06/15.
//  Copyright (c) 2015 Sanoma MDC. All rights reserved.
//
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface FUFonts : NSObject

+ (void) logAvailableFontNames;

@end
